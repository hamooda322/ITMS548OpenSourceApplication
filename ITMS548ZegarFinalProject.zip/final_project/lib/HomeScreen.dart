import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'ResponseScreen.dart';

void main() {
  runApp(const Start());
}

class Start extends StatelessWidget {
  const Start({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Security Data Portal',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.lightBlue),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Security Data Portal'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late bool load;

  @override
  void initState() {
    super.initState();
    load = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: [
          if (load)
            const Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 15, 0),
                child: CircularProgressIndicator()),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Center(
                child: Column(children: [
              ElevatedButton(
                  onPressed: load
                      ? null
                      : () async {
                          setState(() {
                            load = true;
                          });
                          Response cve_response =
                              await get(Uri.https('cve.circl.lu', '/api/last'));
                          setState(() {
                            load = false;
                          });
                          String response;
                          if (cve_response.statusCode == 200) {
                            response = cve_response.body;
                          } else {
                            response =
                                "Sorry an error has occurred. Try again later.";
                          }

                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ResponseScreen(
                                        response: response,
                                      )));
                        },
                  child: Text("CVE Data", style: TextStyle(fontSize: 20))),
              const SizedBox(height: 100),
              ElevatedButton(
                  onPressed: load
                      ? null
                      : () async {
                          setState(() {
                            load = true;
                          });
                          Response nvd_response = await get(Uri.https(
                              'services.nvd.nist.gov', '/rest/json/cves/2.0'));
                          setState(() {
                            load = false;
                          });
                          String response;
                          if (nvd_response.statusCode == 200) {
                            response = nvd_response.body;
                          } else {
                            response =
                                "Sorry an error has occurred. Try again later.";
                          }

                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ResponseScreen(
                                        response: response,
                                      )));
                        },
                  child:
                      const Text("NVD Data", style: TextStyle(fontSize: 20))),
              const SizedBox(height: 100),
              ElevatedButton(
                  onPressed: load
                      ? null
                      : () async {
                          setState(() {
                            load = true;
                          });
                          Response hackerone_response = await get(Uri.https(
                              'api.hackerone.com', '/v1/hackers/hacktivity', {
                            'muhammadzegar':
                                '46ZGdHOzEGG6s7rN7X5kUYxuavNNskxpFdzI0DYOSmA='
                          }));
                          setState(() {
                            load = false;
                          });
                          String response;
                          if (hackerone_response.statusCode == 200) {
                            response = hackerone_response.body;
                          } else {
                            response =
                                "Sorry an error has occurred. Try again later.";
                          }

                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ResponseScreen(
                                        response: response,
                                      )));
                        },
                  child: const Text("Hackerone Data",
                      style: TextStyle(fontSize: 20)))
            ]))
          ],
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
